package br.com.sistemaescolar.sistema_escolar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaEscolarApplicationTests {

	@Test
	void contextLoads() {
	}

}
